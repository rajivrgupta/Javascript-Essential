


//---Que. 1 - Create a webpage containing an image and three buttons --------------------------------------------------------------//
function changeImage(id){
    debugger;
    let ID = id;
    const imageElement = document.getElementById("MyImage");

    let newURL = "https://i.pinimg.com/originals/3f/c0/98/3fc09868b5de1ddc853efd064ec461df.jpg";

    if(ID == "button1")
      nerURL = "https://i.pinimg.com/originals/3f/c0/98/3fc09868b5de1ddc853efd064ec461df.jpg";
    else if(ID == "button2")
      newURL="https://images.indianexpress.com/2019/07/henry-cavill-1200.jpg";
    else if(ID == "button3")
      newURL="https://cdn.dnaindia.com/sites/default/files/styles/full/public/2020/08/17/919756-sushant-singh-rajput-kushal-zaveri-whatsapp-chat-final.png";

    imageElement.src = newURL;
}





//---Que. 2 - Create a webpage containing two input fields and a button --------------------------------------------------------//

function copyText(){
    debugger;
    let inputOneValue = document.getElementById("inputOne").value;
    let inputOne = document.getElementById("inputtwo");
    inputOne.value = inputOneValue;
}







//---Que. 3 - Create an array of objects with objects having the following properties ------------------------------------------//
    // A. {name (string), age (number), country (string), hobbies array (string [ ] ) }
    // B. Write a function to display all the objects on the console

let Employee =[
    {
        Name : "Rajiv",
        Age : 28,
        Country : "India",
        Hobbies : ["Watching News","Playing Badminton","Listining Songs"]
    },
    {
        Name : "Anand",
        Age : 34,
        Country : "Dubai",
        Hobbies : ["Watching News","Playing Badminton","Listining Songs"]  
    },
    {
        Name : "Vivek",
        Age : 32,
        Country : "America",
        Hobbies : ["Watching News","Playing Badminton","Listining Songs"]  
    },
    {
        Name : "Rajesh",
        Age : 29,
        Country : "India",
        Hobbies : ["Watching News","Playing Badminton","Listining Songs"]  
    }
] 

    // function to display all the objects on the console
    console.log("All Objects :");

    function DisplayAll(){
        for (let i in Employee) {
            let j = Employee[i];
                console.log(i+": ", j);
          }
    }
 
    DisplayAll();

//---Que. 4 - Following the 3rd question ------------------------------------------//
    // A. Write a function to display all the objects having age less than 30
    // B. Write a function to display all the objects having country India


        //  function to display all the objects having age less than 30
        console.log("objects having age less than 30 :");
        
        let filteredEmployees = Employee.filter(function( ele ) {
            return ele.Age < 30;
        }); 

        function DisplayAgeLessthan30(){
                for (let i in filteredEmployees) {
                    let j = filteredEmployees[i];
                        console.log(i+": ", j);
                }     
        }
        DisplayAgeLessthan30();


        //  function to display all the objects having country India
        console.log("objects having country India :");
        
        let countryIndia = Employee.filter(function( ele ) {
            return ele.Country ==  "India";
        }); 

        function DisplaycountryIndia(){
                for (let i in countryIndia) {
                    let j = countryIndia[i];
                     console.log(i+": ", j);
                }     
        }
        DisplaycountryIndia();
