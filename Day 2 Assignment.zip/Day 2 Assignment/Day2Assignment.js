
// Que. 1 -  Program to search for a particular character in a string-----------------------------------------------------------------------

let name = "Javascript Assignment";
console.log(name);                                                     // J a v a s c r i p t       A  s  s  i  g  n  m  e  n  t
console.log("Index number of g is : " + name.indexOf("n"));            // | | | | | | | | | |   |   |  |  |  |  |  |  |  |  |  |
                                                                       // 0 1 2 3 4 5 6 7 8 9  10   11 12 13 14 15 16 17 18 19 20





 // Que. 2 - Program to convert minutes to seconds------------------------------------------------------------------------------------------

 let minute = 2;
 let second = minute * 60;
 console.log(minute +" Minute = " + second + " seconds !");






 // Que. 3 - Program to search for a element in a array of strings--------------------------------------------------------------------------

 let arraydata = ["Rajiv", "Alok", "Vivek", "Sagar", "Brijesh"];
 let Isfound = false

 for(let i = 0; i < arraydata.length;)
 {
    if(arraydata[i] == "Sagar")
    {
        Isfound = true
        i = arraydata.length;
    }
    else
        i++;
 }
 
 if(Isfound == true)
 console.log("Given name is exist in the Array !");
 else
 console.log("Given name is not exist in the Array !");




   

 // Que. 4 - Program to display only elements containing 'a' in them from a array-----------------------------------------------------------

 let arraynames = ["Rajiv", "Alok", "Vivek", "Sagar", "Brijesh"];
 let names = [];
    for(let i = 0; i<arraynames.length; i++)
    {
        if(arraynames[i].includes("a"))
        {
            names.push(arraynames[i]);
        }
    }

    console.log("Names containing 'a' are : " + names);





 // Que. 4 - Print an array in reverse order------------------------------------------------------------------------------------------------

 let Cities = ["Mumbai","Pune","Lucknow","Deoria"];
 console.log(Cities.reverse());
 
