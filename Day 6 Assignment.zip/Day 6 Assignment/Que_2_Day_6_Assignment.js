
  
   
   
   window.onload = function () {
    let InitialBuses = [];
    if (localStorage.getItem("PermanentBuses") == null) {
        localStorage.setItem("PermanentBuses", JSON.stringify(InitialBuses));
      }
    };
    

  // Display Function -----------------------------------------------------------------------------------------------
 

    function display(BusesArray = undefined) {
    let tabledata = "";
    let Buses;

    if (BusesArray == undefined) {
        Buses = JSON.parse(localStorage.getItem("PermanentBuses"));
      } else {
        Buses = BusesArray;
      }
  
    Buses.forEach(function (Bus, index) {
      let currentrow = `<tr>
      <td>${index + 1}</td>
      <td>${Bus.busname}</td>
      <td>${Bus.busno}</td>
      <td>${Bus.source}</td>
      <td>${Bus.destination}</td>
      <td>${Bus.pascapacity}</td>
      </td>
      </tr>`;
  
      tabledata += currentrow;
    });
  
    document.getElementsByClassName("tdata")[0].innerHTML = tabledata;
   }
  
   display();

   // Add Function -----------------------------------------------------------------------------------------------

   function addBus(e) {
    e.preventDefault();

    let Bus = {};

    let BusName = document.getElementById("busname").value;
    let BusNo = document.getElementById("busno").value;
    let Source = document.getElementById("source").value;
    let Destination = document.getElementById("destination").value;
    let PacCapicity = document.getElementById("pascapacity").value;

    Bus.busname = BusName;
    Bus.busno = BusNo;
    Bus.source = Source;
    Bus.destination = Destination;
    Bus.pascapacity = Number(PacCapicity);
  
    let PermanentBuses = JSON.parse(localStorage.getItem("PermanentBuses"));
    PermanentBuses.push(Bus);
    localStorage.setItem("PermanentBuses", JSON.stringify(PermanentBuses));
  
    display();
  
    document.getElementById("busname").value = "";
    document.getElementById("busno").value = "";
    document.getElementById("source").value = "";
    document.getElementById("destination").value = "";
    document.getElementById("pascapacity").value = "";
  }
  


  // Search Function -----------------------------------------------------------------------------------------------
  
  function searchBus() {
    let searchsource = document.getElementById("searchSource").value;
    let searcdestination = document.getElementById("searchDestination").value;
  
    let PermanentBuses = JSON.parse(localStorage.getItem("PermanentBuses"));
    
    let newdata = PermanentBuses.filter(function (Bus) {
      return (
        (Bus.source.toUpperCase().indexOf(searchsource.toUpperCase()) != -1) &&
        (Bus.destination.toUpperCase().indexOf(searcdestination.toUpperCase()) != -1)
      );
    });
  
    display(newdata);
  }


  
  