
  
let friends = [
  {
    Name: "Rajiv Gupta",
    Age: 28,
    City: "Gorakhapur",
    Salary: "30000",
  },
  {
    Name: "Arvind Yadav",
    Age: 30,
    City: "Deoria",
    Salary: "15000",
  },
  {
    Name: "Sagar Pol",
    Age: 29,
    City: "Mumbai",
    Salary: "32000",
  },
  {
    Name: "Satyendra Mishra",
    Age: 30,
    City: "Patna",
    Salary: "30000",
  },
  {
    Name: "Vivek Mishra",
    Age: 29,
    City: "Bhatni",
    Salary: "30000",
  }
];

// Display Function -----------------------------------------------------------------------------------------------

function display(friends) {
  let tabledata = "";

  friends.forEach(function (friend, index) {
    let currentrow = `<tr>
    <td>${index + 1}</td>
    <td>${friend.Name}</td>
    <td>${friend.Age}</td>
    <td>${friend.City}</td>
    <td>${friend.Salary}</td>
    <td>
    <button onclick='deletefriend(${index})'>Delete</button>
    </td>
    </tr>`;

    tabledata += currentrow;
  });

  document.getElementsByClassName("tdata")[0].innerHTML = tabledata;
 
}

display(friends);

// Search Function -----------------------------------------------------------------------------------------------

function search() {
  let searchValue = document.getElementById("searchName").value;

  let newdata = friends.filter(function (friend) {
    return (
      (friend.Name.toUpperCase().indexOf(searchValue.toUpperCase()) != -1) || (friend.City.toUpperCase().indexOf(searchValue.toUpperCase()) != -1)
    );
  });

  display(newdata);
}

// Delete Function -----------------------------------------------------------------------------------------------

function deletefriend(index) {
    friends.splice(index, 1);
  display(friends);
}


